<div id="header">
    <img id="logo" src="<?=base_url()?>images/templates/default/logo.png"/>
    <div id="navmenu">
        <ul>
            <li class="active"><a href="#"><img class="menuimg" src="<?=base_url()?>images/home.png"/><p>Menu 1</p></a></li>
            <li><a href="#"><img class="menuimg" src="<?=base_url()?>images/company.png"/><p>Menu 2</p></a></li>
            <li><a href="#"><img class="menuimg" src="<?=base_url()?>images/contacts.png"/><p>Menu 3</p></a></li>
            <li><a href="#"><img class="menuimg" src="<?=base_url()?>images/camera-90.png"/><p>Menu 4</p></a></li>
            <li><a href="#"><img class="menuimg" src="<?=base_url()?>images/camera-90.png"/><p>Menu 5</p></a></li>
        </ul>
    </div>
    <div class="clear"></div>
</div>