<div id="left">
    <div id="banner"></div>
    <div class="bortop"></div>
    <div class="borleft">
        <div class="borright">
            <div class="content">
                <div id="tab">
                    <ul>
                        <li class="current"><a href="#">Máy chụp ảnh</a></li>
                        <li><a href="#">Máy quay phim</a></li>
                        <li><a href="#">Máy nghe nhạc</a></li>
                        <li><a href="#">Kim từ điển</a></li>
                        <li><a href="#">Máy tính bảng</a></li>
                        <li><a href="#">Ổ cứng di động</a></li>
                        <li class="last-item"><a href="#">Phụ kiện</a></li>
                    </ul>
                    <div id="nav-arrow"></div>
                </div>
                <div id="tab_content">
                	<div class="section current">
                        <div class="search clear">
                            <form action="#">
                                Tên sp: <input type="text" name="txtname" />
                                <select name="ddlbrand">
                                    <option value="0">Tất cả các hãng</option>
                                    <option value="1">Apple</option>
                                    <option value="2">Sony</option>
                                </select>
                                <select name="ddlpricefrom">
                                    <option value="0">Giá từ...</option>
                                    <option value="1">10,000,000</option>
                                    <option value="2">50,000,000</option>
                                </select>
                                <select name="ddlpriceto">
                                    <option value="0">Giá đến...</option>
                                    <option value="1">50,000,000</option>
                                    <option value="2">100,000,000</option>
                                </select>
                                <input type="submit" id="btnsearch" value=" " name="btnsearch"/>
                                <span id="btnAdvance">Tìm mở rộng</span>
                            </form>
                        </div>
                        <div class="section_content">apple</div>
                    </div>
                    <div class="section" style="display:none;">
                        <div class="search clear">
                            <form action="#">
                                Tên sp: <input type="text" name="txtname" />
                                <select name="ddlbrand">
                                    <option value="0">Tất cả các hãng</option>
                                    <option value="1">Apple</option>
                                    <option value="2">Sony</option>
                                </select>
                                <select name="ddlpricefrom">
                                    <option value="0">Giá từ...</option>
                                    <option value="1">10,000,000</option>
                                    <option value="2">50,000,000</option>
                                </select>
                                <select name="ddlpriceto">
                                    <option value="0">Giá đến...</option>
                                    <option value="1">50,000,000</option>
                                    <option value="2">100,000,000</option>
                                </select>
                                <input type="submit" id="btnsearch" value=" " name="btnsearch"/>
                                <span id="btnAdvance">Tìm mở rộng</span>
                            </form>
                        </div>
                        <div class="section_content">sony</div>
                    </div>
                    <div class="section" style="display:none;">
                        <div class="search clear">
                            <form action="#">
                                Tên sp: <input type="text" name="txtname" />
                                <select name="ddlbrand">
                                    <option value="0">Tất cả các hãng</option>
                                    <option value="1">Apple</option>
                                    <option value="2">Sony</option>
                                </select>
                                <select name="ddlpricefrom">
                                    <option value="0">Giá từ...</option>
                                    <option value="1">10,000,000</option>
                                    <option value="2">50,000,000</option>
                                </select>
                                <select name="ddlpriceto">
                                    <option value="0">Giá đến...</option>
                                    <option value="1">50,000,000</option>
                                    <option value="2">100,000,000</option>
                                </select>
                                <input type="submit" id="btnsearch" value=" " name="btnsearch"/>
                                <span id="btnAdvance">Tìm mở rộng</span>
                            </form>
                        </div>
                    </div>
                    <div class="section" style="display:none;">
                        <div class="search clear">
                            <form action="#">
                                Tên sp: <input type="text" name="txtname" />
                                <select name="ddlbrand">
                                    <option value="0">Tất cả các hãng</option>
                                    <option value="1">Apple</option>
                                    <option value="2">Sony</option>
                                </select>
                                <select name="ddlpricefrom">
                                    <option value="0">Giá từ...</option>
                                    <option value="1">10,000,000</option>
                                    <option value="2">50,000,000</option>
                                </select>
                                <select name="ddlpriceto">
                                    <option value="0">Giá đến...</option>
                                    <option value="1">50,000,000</option>
                                    <option value="2">100,000,000</option>
                                </select>
                                <input type="submit" id="btnsearch" value=" " name="btnsearch"/>
                                <span id="btnAdvance">Tìm mở rộng</span>
                            </form>
                        </div>
                    </div>
                    <div class="section" style="display:none;">
                        <div class="search clear">
                            <form action="#">
                                Tên sp: <input type="text" name="txtname" />
                                <select name="ddlbrand">
                                    <option value="0">Tất cả các hãng</option>
                                    <option value="1">Apple</option>
                                    <option value="2">Sony</option>
                                </select>
                                <select name="ddlpricefrom">
                                    <option value="0">Giá từ...</option>
                                    <option value="1">10,000,000</option>
                                    <option value="2">50,000,000</option>
                                </select>
                                <select name="ddlpriceto">
                                    <option value="0">Giá đến...</option>
                                    <option value="1">50,000,000</option>
                                    <option value="2">100,000,000</option>
                                </select>
                                <input type="submit" id="btnsearch" value=" " name="btnsearch"/>
                                <span id="btnAdvance">Tìm mở rộng</span>
                            </form>
                        </div>
                    </div>
                    <div class="section" style="display:none;">
                        <div class="search clear">
                            <form action="#">
                                Tên sp: <input type="text" name="txtname" />
                                <select name="ddlbrand">
                                    <option value="0">Tất cả các hãng</option>
                                    <option value="1">Apple</option>
                                    <option value="2">Sony</option>
                                </select>
                                <select name="ddlpricefrom">
                                    <option value="0">Giá từ...</option>
                                    <option value="1">10,000,000</option>
                                    <option value="2">50,000,000</option>
                                </select>
                                <select name="ddlpriceto">
                                    <option value="0">Giá đến...</option>
                                    <option value="1">50,000,000</option>
                                    <option value="2">100,000,000</option>
                                </select>
                                <input type="submit" id="btnsearch" value=" " name="btnsearch"/>
                                <span id="btnAdvance">Tìm mở rộng</span>
                            </form>
                        </div>
                    </div>
                    <div class="section" style="display:none;">
                        <div class="search clear">
                            <form action="#">
                                Tên sp: <input type="text" name="txtname" />
                                <select name="ddlbrand">
                                    <option value="0">Tất cả các hãng</option>
                                    <option value="1">Apple</option>
                                    <option value="2">Sony</option>
                                </select>
                                <select name="ddlpricefrom">
                                    <option value="0">Giá từ...</option>
                                    <option value="1">10,000,000</option>
                                    <option value="2">50,000,000</option>
                                </select>
                                <select name="ddlpriceto">
                                    <option value="0">Giá đến...</option>
                                    <option value="1">50,000,000</option>
                                    <option value="2">100,000,000</option>
                                </select>
                                <input type="submit" id="btnsearch" value=" " name="btnsearch"/>
                                <span id="btnAdvance">Tìm mở rộng</span>
                            </form>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="borbottom"></div>
</div>