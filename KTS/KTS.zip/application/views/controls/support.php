<div class="bortop"></div>
<div class="borleft">
    <div class="borright">
        <div class="content">
            <div class="box_title">
                Hỗ trợ
            </div>
            <div class="box_content" >
				<center><img src="<?=base_url()?>images/templates/default/loading.gif" /></center>
            </div>
        </div>
    </div>
</div>
<div class="borbottom"></div>