<div class="bortop"></div>
<div class="borleft">
    <div class="borright">
        <div class="content">
            <div class="box_content">
            <?php if ($loged): ?>
                <div class="welcome">Xin chào, <span class="bold"><?= $fullname;?></span></div>
                <ul class="userfunc">
                	<li><a href="#">Thông tin cá nhân</a></li>
                	<li><a href="#">Đơn hàng của bạn</a></li>
                </ul>
                <div class="logout"><a href="#" id="logout"><img src="<?=base_url()?>images/templates/default/btnlogout.png"/></a></div>
            <?php else: ?>
                <form method="post" >
                    <table cellspacing="0" id="login">
                        <colgroup>
                            <col class="col1" />
                            <col class="col2" />
                        </colgroup>
                        <tbody>
                            <tr>
                                <td>Tên đăng nhập</td>
                                <td><input type="text" name="username" id="login_username"/></td>
                            </tr>
                            <tr>
                                <td>Mật khẩu</td>
                                <td><input type="password" name="password" id="login_password"/></td>
                            </tr>
                            <tr>
                                <td><a href="#" style="font-size:90%;">Quên mật khẩu?</a></td>
                                <td align="right"><input type="submit" id="btnlogin" name="login" value=" "/></td>
                            </tr>
                        </tbody>
                    </table>
                    <p class="link"><a href="#">Đăng ký thành viên</a></p>
                </form>
            <?php endif;?>
            </div>
        </div>
    </div>
</div>
<div class="borbottom"></div>