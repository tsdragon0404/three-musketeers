<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

	public function index()
	{
	}
	
	public function ajax_login()
	{
		$this->load->library('form_validation');
		$this->load->helper('form');
		
		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		
		$this->users->username = $this->input->post('username');
		$this->users->password = md5($this->input->post('password'));
		//$this->users->remember = $this->input->post('remember');
		
		if ($this->users->username != FALSE && $this->users->password != FALSE )//&& $this->users->remember != FALSE)
		{
			if ($this->form_validation->run())
			{
				$data_login['loged'] = $this->users->login();
				$data_login['fullname'] = $this->session->userdata('fullname');
				
				echo $this->load->view('controls/login', $data_login, TRUE);
			}
			else
				echo "";
		}
		else
			echo "";
	}
	
	public function ajax_logout()
	{
		$this->users->logout();
		$data_login['loged'] = FALSE;
		echo $this->load->view('controls/login', $data_login, TRUE);
	}
}
?>