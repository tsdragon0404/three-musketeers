<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {
	
	public function index()
	{	
		$data['title'] = "KTS online - Homepage";
		$data['header'] = $this->get_view_html('client/header');
		
		$data_login['loged'] = $this->session->userdata('loged_in');
		$data_login['fullname'] = $this->session->userdata('fullname');
		$data['control_login'] = $this->get_view_html('controls/login', $data_login);
		
		$data_support['list'] = $this->supporters->get_all_supporters();
		$data['control_support'] = $this->get_view_html('controls/support', $data_support);
		$this->load->view('master', $data);
	}
	
	private function get_view_html($viewname, $data = ''){
		return $this->load->view($viewname, $data, true);
	}
	
	public function getSupporters()
	{
		echo $this->supporters->get_supporters_html();
	}
}
?>